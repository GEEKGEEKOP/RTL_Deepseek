// این اسکریپت فقط برای انجام هر نوع عملکرد اضافی است، برای راست‌چین کردن کافی نیست.
console.log("Text alignment extension is running.");

